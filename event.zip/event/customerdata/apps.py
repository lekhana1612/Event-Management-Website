from django.apps import AppConfig


class CustomerdataConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'customerdata'
